.model small
.stack 100h

.data
num db 25
quot db ?
rem db ?

.code
main proc
mov ax,@data
mov ds,ax

mov al,num
mov bl,10
div bl

mov quot,al
mov rem,ah

mov ah,4ch
int 21h
main endp
end main