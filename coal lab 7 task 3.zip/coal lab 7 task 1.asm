.model small
.stack 100h

.data
length db 5
width  db 4
area   db ?

.code
main proc
mov ax,@data
mov ds,ax

mov al,length
mov bl,width
mul bl

mov area,al

mov ah,4ch
int 21h
main endp
end main
