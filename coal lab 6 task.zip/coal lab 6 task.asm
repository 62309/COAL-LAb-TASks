.model small
.stack 100h

.data
name db 'Full Name: Nimra Ali',13,10,'$'
sap db 'SAP ID: 123456',13,10,'$'
batch db 'Batch: 2024',13,10,'$'
program db 'Program: BSSE Semester 1',13,10,'$'

.code
main proc
mov ax,@data
mov ds,ax

mov ah,09h

int 21h

mov ah,09h
mov dx, offset sap
int 21h

mov ah,09h
mov dx, offset batch
int 21h

mov ah,09h
mov dx, offset program
int 21h

mov ah,4ch
int 21h

main endp
end main